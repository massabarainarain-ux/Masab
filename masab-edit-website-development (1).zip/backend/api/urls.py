from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    WebsiteSettingViewSet, ServiceViewSet, PortfolioItemViewSet,
    OfferViewSet, ReviewViewSet, OrderViewSet, ToolViewSet, CouponViewSet
)

router = DefaultRouter()
router.register(r'settings', WebsiteSettingViewSet)
router.register(r'services', ServiceViewSet)
router.register(r'portfolio', PortfolioItemViewSet)
router.register(r'offers', OfferViewSet)
router.register(r'reviews', ReviewViewSet)
router.register(r'orders', OrderViewSet)
router.register(r'tools', ToolViewSet)
router.register(r'coupons', CouponViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
