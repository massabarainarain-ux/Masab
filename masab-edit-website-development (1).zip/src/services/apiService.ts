import axios from 'axios';
import { API_CONFIG } from '../config/apiConfig';

const api = axios.create({
  baseURL: API_CONFIG.BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const apiService = {
  // Get all website settings and data
  getSiteData: async () => {
    try {
      const response = await api.get('/site-data/');
      return response.data;
    } catch (error) {
      console.warn('Backend server not running yet. Using local fallback data.');
      throw error;
    }
  },

  // Save specific section to database
  updateSection: async (sectionName: string, data: any) => {
    try {
      const response = await api.post(`/update-section/`, {
        section: sectionName,
        data: data,
      });
      return response.data;
    } catch (error) {
      console.error('Failed to save to database. Ensure Django server is running.', error);
      throw error;
    }
  },

  // Update whole website data
  updateSiteData: async (fullData: any) => {
    try {
      const response = await api.post('/update-all/', fullData);
      return response.data;
    } catch (error) {
      console.error('Failed to save to database.', error);
      throw error;
    }
  }
};
