import { Link } from 'react-router-dom';
import { useSite } from '../context/SiteContext';
import { motion } from 'framer-motion';
import { CheckCircle, Sparkles } from 'lucide-react';

export default function Offers() {
  const { data } = useSite();

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-accent/10 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Sparkles size={16} /> Limited Time Offers
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.offersTitle}</h1>
          <p className="text-muted max-w-xl mx-auto">{data.siteTexts.offersSubtitle}</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {data.offers.map((offer, i) => (
            <motion.div
              key={offer.id}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 }}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 border border-gray-100"
            >
              <div className="bg-gradient-to-r from-accent to-purple-500 p-6 text-white relative overflow-hidden">
                <div className="absolute -right-6 -top-6 w-24 h-24 bg-white/10 rounded-full" />
                <div className="absolute -right-2 -bottom-8 w-16 h-16 bg-white/10 rounded-full" />
                <span className="inline-block bg-white/20 text-xs font-bold px-3 py-1 rounded-full mb-3">{offer.badge}</span>
                <h3 className="text-xl font-bold">{offer.title}</h3>
              </div>
              <div className="p-8">
                <p className="text-muted text-sm mb-6">{offer.description}</p>
                <div className="flex items-baseline gap-3 mb-6">
                  <span className="text-4xl font-bold font-[Space_Grotesk]">${offer.discountPrice}</span>
                  <span className="text-lg text-muted line-through">${offer.originalPrice}</span>
                  <span className="text-green-600 text-sm font-bold bg-green-50 px-2 py-0.5 rounded">
                    {Math.round((1 - offer.discountPrice / offer.originalPrice) * 100)}% OFF
                  </span>
                </div>
                <ul className="space-y-3 mb-8">
                  {offer.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-2 text-sm">
                      <CheckCircle size={16} className="text-green-500 shrink-0" /> {f}
                    </li>
                  ))}
                </ul>
                <Link
                  to="/order"
                  className="block text-center py-3.5 rounded-xl font-semibold bg-accent text-white hover:bg-accent-light transition-all duration-300"
                >
                  Claim This Offer
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
