import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useSite } from '../context/SiteContext';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Calculator } from 'lucide-react';

export default function Services() {
  const { data } = useSite();
  const [calcLength, setCalcLength] = useState(5);
  const [calcType, setCalcType] = useState(0);
  const [calcSubtitles, setCalcSubtitles] = useState(false);
  const [calcEffects, setCalcEffects] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ discount: number; type: string } | null>(null);

  const basePrice = data.services[calcType]?.price || 25;
  const lengthMultiplier = calcLength <= 5 ? 1 : calcLength <= 15 ? 1.5 : calcLength <= 30 ? 2 : 3;
  const subtitleCost = calcSubtitles ? 10 : 0;
  const effectsCost = calcEffects ? 15 : 0;
  let totalPrice = basePrice * lengthMultiplier + subtitleCost + effectsCost;

  if (appliedCoupon) {
    if (appliedCoupon.type === 'percent') {
      totalPrice = totalPrice * (1 - appliedCoupon.discount / 100);
    } else {
      totalPrice = totalPrice - appliedCoupon.discount;
    }
  }
  totalPrice = Math.max(0, totalPrice);

  const applyCoupon = () => {
    const coupon = data.coupons.find(c => c.code.toUpperCase() === couponCode.toUpperCase() && c.active);
    if (coupon) {
      setAppliedCoupon({ discount: coupon.discount, type: coupon.type });
    } else {
      setAppliedCoupon(null);
      alert('Invalid coupon code');
    }
  };

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.servicesTitle}</h1>
          <p className="text-muted max-w-xl mx-auto">{data.siteTexts.servicesSubtitle}</p>
        </motion.div>

        {/* Pricing Table */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {data.services.map((service, i) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.15 }}
              className={`bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 relative group hover:-translate-y-1 border ${service.popular ? 'border-accent ring-1 ring-accent' : 'border-gray-100'}`}
            >
              {service.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-white text-xs font-bold px-4 py-1 rounded-full">
                  MOST POPULAR
                </span>
              )}
              <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors">{service.name}</h3>
              <p className="text-muted text-sm mb-6 min-h-[3rem]">{service.description}</p>
              <div className="text-4xl font-bold font-[Space_Grotesk] mb-1">{data.currencySymbol || '$'}{service.price}</div>
              <p className="text-muted text-sm mb-8">Delivery: {service.deliveryTime}</p>
              <ul className="space-y-3 mb-8">
                {service.features.map((f, j) => (
                  <li key={j} className="flex items-center gap-2 text-sm">
                    <CheckCircle size={16} className="text-green-500 shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              <Link
                to="/order"
                className={`block text-center py-3.5 rounded-xl font-semibold transition-all duration-300 ${
                  service.popular
                    ? 'bg-accent text-white hover:bg-accent-light'
                    : 'bg-gray-100 hover:bg-primary hover:text-white'
                }`}
              >
                Order Now
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Price Calculator */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                <Calculator size={20} className="text-accent" />
              </div>
              <div>
                <h2 className="text-2xl font-bold font-[Space_Grotesk]">Price Calculator</h2>
                <p className="text-muted text-sm">Get an instant estimate</p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2">Video Length: {calcLength} minutes</label>
                <input
                  type="range"
                  min={1}
                  max={60}
                  value={calcLength}
                  onChange={e => setCalcLength(+e.target.value)}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted mt-1">
                  <span>1 min</span><span>60 min</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Editing Type</label>
                <div className="grid grid-cols-3 gap-3">
                  {data.services.map((s, i) => (
                    <button
                      key={s.id}
                      onClick={() => setCalcType(i)}
                      className={`p-3 rounded-xl text-sm font-medium transition-all ${
                        calcType === i ? 'bg-accent text-white' : 'bg-gray-100 hover:bg-gray-200'
                      }`}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={calcSubtitles}
                    onChange={e => setCalcSubtitles(e.target.checked)}
                    className="w-4 h-4 rounded accent-accent"
                  />
                  <span className="text-sm">Add Subtitles (+{data.currencySymbol || '$'}10)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={calcEffects}
                    onChange={e => setCalcEffects(e.target.checked)}
                    className="w-4 h-4 rounded accent-accent"
                  />
                  <span className="text-sm">Extra Effects (+{data.currencySymbol || '$'}15)</span>
                </label>
              </div>

              <div className="flex gap-3">
                <input
                  type="text"
                  placeholder="Coupon code"
                  value={couponCode}
                  onChange={e => setCouponCode(e.target.value)}
                  className="flex-1 px-4 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-accent"
                />
                <button
                  onClick={applyCoupon}
                  className="px-4 py-2 bg-gray-100 rounded-xl text-sm font-medium hover:bg-gray-200 transition-all"
                >
                  Apply
                </button>
              </div>
              {appliedCoupon && (
                <p className="text-green-600 text-sm font-medium">
                  ✅ Coupon applied! {appliedCoupon.discount}{appliedCoupon.type === 'percent' ? '%' : '$'} off
                </p>
              )}

              <div className="pt-6 border-t border-gray-100">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">Estimated Total</span>
                  <span className="text-3xl font-bold font-[Space_Grotesk] text-accent">{data.currencySymbol || '$'}{totalPrice.toFixed(2)}</span>
                </div>
              </div>

              <Link
                to="/order"
                className="block text-center py-4 rounded-xl font-semibold bg-primary text-white hover:bg-gray-800 transition-all duration-300 flex items-center justify-center gap-2"
              >
                Proceed to Order <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
