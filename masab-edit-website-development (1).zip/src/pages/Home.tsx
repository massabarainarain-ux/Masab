import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSite } from '../context/SiteContext';
import { motion } from 'framer-motion';
import { ArrowRight, Play, Star, CheckCircle, ExternalLink } from 'lucide-react';

function useInView(ref: React.RefObject<HTMLElement | null>) {
  const [inView, setInView] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold: 0.1 });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, [ref]);
  return inView;
}

function Section({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref);
  return (
    <div ref={ref} className={`transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'} ${className}`}>
      {children}
    </div>
  );
}

export default function Home() {
  const { data } = useSite();

  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="min-h-[90vh] flex items-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-white to-purple-50" />
        <div className="absolute top-20 right-20 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-72 h-72 bg-purple-100/50 rounded-full blur-3xl" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10 w-full">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 bg-accent/10 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Play size={14} className="fill-accent" /> Now accepting new clients
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-[Space_Grotesk] leading-tight mb-6">
                {data.hero.title}
              </h1>
              <p className="text-lg text-muted mb-8 max-w-lg">
                {data.hero.subtitle}
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/order"
                  className="px-8 py-4 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all duration-300 hover:shadow-xl hover:shadow-gray-200 flex items-center gap-2 group"
                >
                  {data.hero.ctaText} <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link
                  to="/portfolio"
                  className="px-8 py-4 border-2 border-gray-200 rounded-xl font-semibold hover:border-accent hover:text-accent transition-all duration-300"
                >
                  View Portfolio
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden md:block"
            >
              <div className="relative">
                <div className="w-full aspect-video bg-gradient-to-br from-accent/20 via-purple-100 to-pink-100 rounded-2xl flex items-center justify-center shadow-2xl shadow-accent/10">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg mx-auto mb-4 hover:scale-110 transition-transform cursor-pointer">
                      <Play size={32} className="text-accent fill-accent ml-1" />
                    </div>
                    <p className="text-gray-600 font-medium">Watch Our Showreel</p>
                  </div>
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white rounded-xl p-4 shadow-lg">
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {['🎬', '🎨', '✨'].map((e, i) => (
                        <span key={i} className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-sm border-2 border-white">{e}</span>
                      ))}
                    </div>
                    <span className="text-sm font-medium">{data.trustStats[1]?.value} clients</span>
                  </div>
                </div>
                <div className="absolute -top-4 -right-4 bg-white rounded-xl p-4 shadow-lg">
                  <div className="flex items-center gap-1">
                    {[1,2,3,4,5].map(i => <Star key={i} size={14} className="text-yellow-400 fill-yellow-400" />)}
                    <span className="text-sm font-medium ml-1">5.0</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Trust Stats */}
      <Section>
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {data.trustStats.map((stat, i) => (
                <motion.div
                  key={stat.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center p-6 rounded-2xl hover:bg-gray-50 transition-all duration-300 group"
                >
                  <div className="text-4xl mb-2">
                    {stat.icon === 'video' ? '🎬' : stat.icon === 'users' ? '👥' : stat.icon === 'clock' ? '⚡' : '⭐'}
                  </div>
                  <div className="text-3xl font-bold font-[Space_Grotesk] mb-1 group-hover:text-accent transition-colors">{stat.value}</div>
                  <div className="text-muted text-sm">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </Section>

      {/* Services Preview */}
      <Section>
        <section className="py-20 bg-surface">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.servicesTitle}</h2>
              <p className="text-muted max-w-xl mx-auto">{data.siteTexts.servicesSubtitle}</p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {data.services.map((service, i) => (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.15 }}
                  viewport={{ once: true }}
                  className={`bg-white rounded-2xl p-8 hover:shadow-xl transition-all duration-300 relative group hover:-translate-y-1 ${service.popular ? 'ring-2 ring-accent' : ''}`}
                >
                  {service.popular && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-white text-xs font-bold px-4 py-1 rounded-full">
                      POPULAR
                    </span>
                  )}
                  <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors">{service.name}</h3>
                  <p className="text-muted text-sm mb-6">{service.description}</p>
                  <div className="text-3xl font-bold font-[Space_Grotesk] mb-1">{data.currencySymbol || '$'}{service.price}</div>
                  <p className="text-muted text-sm mb-6">Delivery: {service.deliveryTime}</p>
                  <ul className="space-y-2 mb-8">
                    {service.features.map((f, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm">
                        <CheckCircle size={16} className="text-green-500 shrink-0" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/order"
                    className="block text-center py-3 rounded-xl font-semibold transition-all duration-300 bg-gray-100 hover:bg-primary hover:text-white"
                  >
                    Order Now
                  </Link>
                </motion.div>
              ))}
            </div>
            <div className="text-center mt-10">
              <Link to="/services" className="inline-flex items-center gap-2 text-accent font-semibold hover:gap-3 transition-all">
                View All Services <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>
      </Section>

      {/* Portfolio Preview */}
      <Section>
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.portfolioTitle}</h2>
              <p className="text-muted max-w-xl mx-auto">{data.siteTexts.portfolioSubtitle}</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.portfolio.slice(0, 6).map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className="group relative rounded-2xl overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200 aspect-video cursor-pointer hover:shadow-xl transition-all duration-300"
                >
                  {item.imageUrl ? (
                    <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-accent/10 via-purple-50 to-pink-50">
                      <span className="text-4xl">🎬</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-6">
                    <span className="text-accent text-xs font-bold uppercase tracking-wider mb-1">{item.category}</span>
                    <h4 className="text-white font-bold text-lg">{item.title}</h4>
                    <p className="text-gray-300 text-sm mt-1">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="text-center mt-10">
              <Link to="/portfolio" className="inline-flex items-center gap-2 text-accent font-semibold hover:gap-3 transition-all">
                View Full Portfolio <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>
      </Section>

      {/* Offers Preview */}
      <Section>
        <section className="py-20 bg-surface">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.offersTitle}</h2>
              <p className="text-muted max-w-xl mx-auto">{data.siteTexts.offersSubtitle}</p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {data.offers.map((offer, i) => (
                <motion.div
                  key={offer.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.15 }}
                  viewport={{ once: true }}
                  className="bg-white rounded-2xl p-8 hover:shadow-xl transition-all duration-300 relative group hover:-translate-y-1"
                >
                  <span className="absolute top-4 right-4 bg-accent/10 text-accent text-xs font-bold px-3 py-1 rounded-full">
                    {offer.badge}
                  </span>
                  <h3 className="text-xl font-bold mb-3 pr-20">{offer.title}</h3>
                  <p className="text-muted text-sm mb-4">{offer.description}</p>
                  <div className="flex items-baseline gap-3 mb-6">
                    <span className="text-3xl font-bold font-[Space_Grotesk] text-accent">{data.currencySymbol || '$'}{offer.discountPrice}</span>
                    <span className="text-lg text-muted line-through">{data.currencySymbol || '$'}{offer.originalPrice}</span>
                  </div>
                  <ul className="space-y-2 mb-8">
                    {offer.features.map((f, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm">
                        <CheckCircle size={16} className="text-green-500 shrink-0" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/order"
                    className="block text-center py-3 rounded-xl font-semibold transition-all duration-300 bg-accent text-white hover:bg-accent-light"
                  >
                    Get This Deal
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </Section>

      {/* Reviews Preview */}
      <Section>
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.reviewsTitle}</h2>
              <p className="text-muted max-w-xl mx-auto">{data.siteTexts.reviewsSubtitle}</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {data.reviews.filter(r => r.approved).slice(0, 4).map((review, i) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className={`bg-surface rounded-2xl p-6 hover:shadow-lg transition-all duration-300 ${review.highlighted ? 'ring-2 ring-accent' : ''}`}
                >
                  <div className="flex gap-1 mb-3">
                    {[1,2,3,4,5].map(s => (
                      <Star key={s} size={14} className={s <= review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'} />
                    ))}
                  </div>
                  <p className="text-sm text-gray-700 mb-4 line-clamp-3">"{review.comment}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center text-accent font-bold text-sm">
                      {review.name[0]}
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{review.name}</p>
                      <p className="text-xs text-muted">{review.date}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="text-center mt-10">
              <Link to="/reviews" className="inline-flex items-center gap-2 text-accent font-semibold hover:gap-3 transition-all">
                Read All Reviews <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>
      </Section>

      {/* CTA */}
      <Section>
        <section className="py-20 bg-primary">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h2 className="text-3xl sm:text-4xl font-bold font-[Space_Grotesk] text-white mb-6">
              Ready to elevate your content?
            </h2>
            <p className="text-gray-400 mb-8 max-w-xl mx-auto">
              Get professional video editing that makes your content stand out. Fast delivery, unlimited revisions.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/order"
                className="px-8 py-4 bg-accent text-white rounded-xl font-semibold hover:bg-accent-light transition-all duration-300 flex items-center gap-2"
              >
                Order Now <ArrowRight size={18} />
              </Link>
              <a
                href={`https://wa.me/${data.whatsapp.phone.replace(/\D/g, '')}?text=${encodeURIComponent(data.whatsapp.message)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 border-2 border-white/20 text-white rounded-xl font-semibold hover:bg-white/10 transition-all duration-300"
              >
                Chat on WhatsApp
              </a>
            </div>
          </div>
        </section>
      </Section>

      {/* Social Links */}
      <Section>
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <h3 className="text-center text-lg font-semibold mb-8 text-muted">Follow Us</h3>
            <div className="flex justify-center gap-4 flex-wrap">
              {data.socialLinks.map(link => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-6 py-3 rounded-full bg-surface hover:bg-accent hover:text-white transition-all duration-300 font-medium text-sm group"
                >
                  <ExternalLink size={16} className="group-hover:rotate-12 transition-transform" />
                  {link.platform}
                </a>
              ))}
            </div>
          </div>
        </section>
      </Section>
    </div>
  );
}
