import { useState } from 'react';
import { useSite } from '../context/SiteContext';
import { motion, AnimatePresence } from 'framer-motion';

export default function Portfolio() {
  const { data } = useSite();
  const categories = ['All', ...Array.from(new Set(data.portfolio.map(p => p.category)))];
  const [activeCategory, setActiveCategory] = useState('All');
  const [sliderPos, setSliderPos] = useState(50);
  const [dragging, setDragging] = useState(false);

  const filtered = activeCategory === 'All'
    ? data.portfolio
    : data.portfolio.filter(p => p.category === activeCategory);

  const handleSliderMove = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>, el: HTMLDivElement) => {
    if (!dragging) return;
    const rect = el.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const pos = ((clientX - rect.left) / rect.width) * 100;
    setSliderPos(Math.max(0, Math.min(100, pos)));
  };

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.portfolioTitle}</h1>
          <p className="text-muted max-w-xl mx-auto">{data.siteTexts.portfolioSubtitle}</p>
        </motion.div>

        {/* Category Filter */}
        <div className="flex justify-center gap-2 mb-12 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === cat
                  ? 'bg-primary text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          <AnimatePresence mode="popLayout">
            {filtered.map(item => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="group relative rounded-2xl overflow-hidden bg-gray-100 aspect-video cursor-pointer"
              >
                {item.imageUrl ? (
                  <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-accent/10 via-purple-50 to-pink-50">
                    <div className="text-center">
                      <span className="text-5xl block mb-2">🎬</span>
                      <span className="text-sm text-muted font-medium">{item.category}</span>
                    </div>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-6">
                  <span className="text-accent text-xs font-bold uppercase tracking-wider mb-1">{item.category}</span>
                  <h4 className="text-white font-bold text-lg">{item.title}</h4>
                  <p className="text-gray-300 text-sm mt-1">{item.description}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Before/After Slider */}
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold font-[Space_Grotesk] text-center mb-8">Before & After Comparison</h2>
          <div
            className="relative rounded-2xl overflow-hidden aspect-video select-none cursor-col-resize shadow-xl"
            onMouseMove={(e) => handleSliderMove(e, e.currentTarget)}
            onTouchMove={(e) => handleSliderMove(e, e.currentTarget)}
            onMouseDown={() => setDragging(true)}
            onMouseUp={() => setDragging(false)}
            onMouseLeave={() => setDragging(false)}
            onTouchStart={() => setDragging(true)}
            onTouchEnd={() => setDragging(false)}
          >
            {/* After (full) */}
            <div className="absolute inset-0 bg-gradient-to-br from-accent/30 via-purple-200 to-pink-200 flex items-center justify-center">
              <div className="text-center">
                <span className="text-6xl block mb-3">✨</span>
                <p className="text-lg font-bold text-gray-700">After Editing</p>
                <p className="text-sm text-gray-500">Color graded & enhanced</p>
              </div>
            </div>

            {/* Before (clipped) */}
            <div
              className="absolute inset-0 bg-gradient-to-br from-gray-300 via-gray-200 to-gray-400 flex items-center justify-center"
              style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
            >
              <div className="text-center">
                <span className="text-6xl block mb-3">📹</span>
                <p className="text-lg font-bold text-gray-600">Before Editing</p>
                <p className="text-sm text-gray-500">Raw footage</p>
              </div>
            </div>

            {/* Slider Handle */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-white shadow-lg"
              style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
            >
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center">
                <span className="text-sm">⟷</span>
              </div>
            </div>

            {/* Labels */}
            <div className="absolute top-4 left-4 bg-black/50 text-white text-xs font-bold px-3 py-1 rounded-full">BEFORE</div>
            <div className="absolute top-4 right-4 bg-accent/80 text-white text-xs font-bold px-3 py-1 rounded-full">AFTER</div>
          </div>
          <p className="text-center text-muted text-sm mt-4">← Drag the slider to compare →</p>
        </div>
      </div>
    </div>
  );
}
