import { useState } from 'react';
import { useSite } from '../context/SiteContext';
import { motion } from 'framer-motion';
import { Send, Upload, Phone, CheckCircle, Clock, Film, Package } from 'lucide-react';

export default function Order() {
  const { data, addOrder } = useSite();
  const [form, setForm] = useState({
    name: '', email: '', serviceType: data.services[0]?.name || '', videoLength: '', description: ''
  });
  const [file, setFile] = useState<File | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [orderId, setOrderId] = useState('');

  // Track order status
  const [trackId, setTrackId] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<typeof data.orders[0] | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = 'ORD-' + Date.now().toString(36).toUpperCase();
    addOrder({
      id,
      name: form.name,
      email: form.email,
      serviceType: form.serviceType,
      videoLength: form.videoLength,
      description: form.description,
      status: 'received',
      date: new Date().toISOString().split('T')[0],
      fileName: file?.name,
    });
    setOrderId(id);
    setSubmitted(true);
    setForm({ name: '', email: '', serviceType: data.services[0]?.name || '', videoLength: '', description: '' });
    setFile(null);
  };

  const trackOrder = () => {
    const found = data.orders.find(o => o.id.toLowerCase() === trackId.toLowerCase());
    setTrackedOrder(found || null);
  };

  const statuses = ['received', 'editing', 'rendering', 'delivered'];
  const statusIcons = [Package, Film, Clock, CheckCircle];
  const statusLabels = ['Order Received', 'Editing', 'Rendering', 'Delivered'];

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.contactTitle}</h1>
          <p className="text-muted max-w-xl mx-auto">{data.siteTexts.contactSubtitle}</p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Contact Info */}
          <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
            <div className="bg-gradient-to-br from-primary to-gray-800 rounded-2xl p-8 text-white h-full">
              <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
              <div className="space-y-6 mb-10">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center">
                    <Phone size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">WhatsApp / Phone</p>
                    <p className="font-semibold text-lg">{data.whatsapp.phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-xl">
                    📧
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Email</p>
                    <p className="font-semibold">massabarainarain@gmail.com</p>
                  </div>
                </div>
              </div>

              <a
                href={`https://wa.me/${data.whatsapp.phone.replace(/\D/g, '')}?text=${encodeURIComponent(data.whatsapp.message)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 px-6 py-3 rounded-xl font-semibold transition-all"
              >
                💬 Chat on WhatsApp
              </a>

              {/* Order Tracker */}
              <div className="mt-10 pt-8 border-t border-white/20">
                <h3 className="font-bold mb-4">Track Your Order</h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Enter Order ID"
                    value={trackId}
                    onChange={e => setTrackId(e.target.value)}
                    className="flex-1 px-4 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:border-accent text-sm"
                  />
                  <button
                    onClick={trackOrder}
                    className="px-4 py-2.5 bg-accent rounded-xl text-sm font-medium hover:bg-accent-light transition-all"
                  >
                    Track
                  </button>
                </div>
                {trackedOrder && (
                  <div className="mt-6">
                    <div className="flex justify-between mb-2">
                      {statuses.map((s, i) => {
                        const Icon = statusIcons[i];
                        const idx = statuses.indexOf(trackedOrder.status);
                        const active = i <= idx;
                        return (
                          <div key={s} className="flex flex-col items-center gap-1">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${active ? 'bg-accent' : 'bg-white/10'}`}>
                              <Icon size={14} />
                            </div>
                            <span className="text-[10px]">{statusLabels[i]}</span>
                          </div>
                        );
                      })}
                    </div>
                    <div className="h-1 bg-white/10 rounded-full mt-2">
                      <div
                        className="h-1 bg-accent rounded-full transition-all duration-500"
                        style={{ width: `${((statuses.indexOf(trackedOrder.status) + 1) / statuses.length) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
                {trackId && !trackedOrder && (
                  <p className="mt-3 text-sm text-red-300">Order not found. Check the ID.</p>
                )}
              </div>
            </div>
          </motion.div>

          {/* Order Form */}
          <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
            {submitted ? (
              <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 text-center">
                <span className="text-5xl block mb-4">🎉</span>
                <h2 className="text-2xl font-bold mb-2">Order Submitted!</h2>
                <p className="text-muted mb-4">Your order ID is:</p>
                <div className="bg-gray-100 rounded-xl px-6 py-4 font-mono text-xl font-bold text-accent mb-6">
                  {orderId}
                </div>
                <p className="text-sm text-muted mb-6">Save this ID to track your order status.</p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all"
                >
                  Place Another Order
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 space-y-5">
                <h2 className="text-2xl font-bold font-[Space_Grotesk] mb-2">Place Your Order</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-1">Name *</label>
                    <input
                      type="text"
                      required
                      value={form.name}
                      onChange={e => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Email *</label>
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={e => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent transition-colors"
                    />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-1">Service Type *</label>
                    <select
                      required
                      value={form.serviceType}
                      onChange={e => setForm({ ...form, serviceType: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent transition-colors bg-white"
                    >
                      {data.services.map(s => (
                        <option key={s.id} value={s.name}>{s.name} - ${s.price}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Video Length</label>
                    <input
                      type="text"
                      placeholder="e.g., 10 minutes"
                      value={form.videoLength}
                      onChange={e => setForm({ ...form, videoLength: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">Project Description *</label>
                  <textarea
                    required
                    rows={4}
                    value={form.description}
                    onChange={e => setForm({ ...form, description: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent transition-colors resize-none"
                    placeholder="Describe your project, style preferences, references..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">Upload File (MP4, MOV, ZIP)</label>
                  <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center hover:border-accent transition-colors cursor-pointer relative">
                    <input
                      type="file"
                      accept=".mp4,.mov,.zip"
                      onChange={e => setFile(e.target.files?.[0] || null)}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <Upload size={24} className="mx-auto mb-2 text-muted" />
                    {file ? (
                      <p className="text-sm font-medium text-accent">{file.name}</p>
                    ) : (
                      <p className="text-sm text-muted">Click or drag to upload your files</p>
                    )}
                    <p className="text-xs text-muted mt-1">Supports MP4, MOV, ZIP</p>
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full py-4 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center justify-center gap-2"
                >
                  <Send size={18} /> Submit Order
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
