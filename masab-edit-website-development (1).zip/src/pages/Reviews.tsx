import { useState } from 'react';
import { useSite } from '../context/SiteContext';
import { motion } from 'framer-motion';
import { Star, Send } from 'lucide-react';

export default function Reviews() {
  const { data, addReview } = useSite();
  const [name, setName] = useState('');
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(5);
  const [submitted, setSubmitted] = useState(false);

  const approved = data.reviews.filter(r => r.approved);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) return;
    addReview({
      id: Date.now().toString(),
      name: name.trim(),
      comment: comment.trim(),
      rating,
      date: new Date().toISOString().split('T')[0],
      approved: false,
      highlighted: false,
    });
    setName('');
    setComment('');
    setRating(5);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.reviewsTitle}</h1>
          <p className="text-muted max-w-xl mx-auto">{data.siteTexts.reviewsSubtitle}</p>
        </motion.div>

        {/* Reviews */}
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {approved.map((review, i) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`bg-white rounded-2xl p-6 shadow-sm border transition-all hover:shadow-lg ${
                review.highlighted ? 'border-accent ring-1 ring-accent/30' : 'border-gray-100'
              }`}
            >
              {review.highlighted && (
                <span className="inline-block bg-accent/10 text-accent text-xs font-bold px-3 py-1 rounded-full mb-3">
                  ⭐ Featured Review
                </span>
              )}
              <div className="flex gap-1 mb-4">
                {[1,2,3,4,5].map(s => (
                  <Star key={s} size={18} className={s <= review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'} />
                ))}
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">"{review.comment}"</p>
              <div className="flex items-center gap-3 border-t border-gray-50 pt-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-accent to-purple-500 flex items-center justify-center text-white font-bold">
                  {review.name[0]}
                </div>
                <div>
                  <p className="font-semibold">{review.name}</p>
                  <p className="text-xs text-muted">{review.date}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Leave a Review */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-xl mx-auto"
        >
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
            <h2 className="text-2xl font-bold font-[Space_Grotesk] mb-6">Leave a Review</h2>

            {submitted ? (
              <div className="text-center py-8">
                <span className="text-4xl block mb-4">🎉</span>
                <h3 className="text-xl font-bold mb-2">Thank you!</h3>
                <p className="text-muted">Your review has been submitted and is pending approval.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-1">Your Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent transition-colors"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">Rating</label>
                  <div className="flex gap-2">
                    {[1,2,3,4,5].map(s => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setRating(s)}
                        className="transition-transform hover:scale-110"
                      >
                        <Star size={28} className={s <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'} />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">Your Review</label>
                  <textarea
                    value={comment}
                    onChange={e => setComment(e.target.value)}
                    required
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent transition-colors resize-none"
                    placeholder="Share your experience..."
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3.5 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center justify-center gap-2"
                >
                  <Send size={18} /> Submit Review
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
