import { useSite } from '../context/SiteContext';
import { motion } from 'framer-motion';
import { Film, Captions, Minimize2, Maximize2, Image, Merge, RefreshCw, Music, FileImage, MessageSquare, Wrench } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const iconMap: Record<string, LucideIcon> = {
  film: Film,
  subtitles: Captions,
  compress: Minimize2,
  resize: Maximize2,
  gif: Image,
  merge: Merge,
  convert: RefreshCw,
  audio: Music,
  image: FileImage,
  speech: MessageSquare,
};

export default function Tools() {
  const { data } = useSite();

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold font-[Space_Grotesk] mb-4">{data.siteTexts.toolsTitle}</h1>
          <p className="text-muted max-w-xl mx-auto">{data.siteTexts.toolsSubtitle}</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {data.tools.map((tool, i) => {
            const Icon = iconMap[tool.icon] || Wrench;
            return (
              <motion.div
                key={tool.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`bg-white rounded-2xl p-6 border border-gray-100 transition-all duration-300 group ${
                  tool.available
                    ? 'hover:shadow-xl hover:-translate-y-1 cursor-pointer'
                    : 'opacity-60'
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors ${
                  tool.available
                    ? 'bg-accent/10 text-accent group-hover:bg-accent group-hover:text-white'
                    : 'bg-gray-100 text-gray-400'
                }`}>
                  <Icon size={22} />
                </div>
                <h3 className="font-bold mb-1 group-hover:text-accent transition-colors">{tool.name}</h3>
                <p className="text-sm text-muted">{tool.description}</p>
                {!tool.available && (
                  <span className="inline-block mt-3 text-xs font-medium bg-gray-100 text-gray-500 px-3 py-1 rounded-full">
                    Coming Soon
                  </span>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
