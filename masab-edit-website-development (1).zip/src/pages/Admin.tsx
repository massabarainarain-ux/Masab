import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useSite } from '../context/SiteContext';
import { motion } from 'framer-motion';
import {
  Settings, FileText, DollarSign, Gift, Image, Star, ShoppingCart,
  Link2, Type, Palette, Wrench, Ticket, LogOut, Plus, Trash2, Save,
  Check, X, Eye, ChevronDown, ChevronRight, MessageCircle
} from 'lucide-react';

type Tab = 'overview' | 'logo' | 'hero' | 'services' | 'offers' | 'portfolio' | 'reviews' | 'orders' | 'social' | 'texts' | 'tools' | 'coupons' | 'whatsapp' | 'trust';

export default function Admin() {
  const { data, updateField, isAdmin, logout, isLive } = useSite();
  const [tab, setTab] = useState<Tab>('overview');
  const [saved, setSaved] = useState(false);

  if (!isAdmin) return <Navigate to="/admin/login" />;

  const showSaved = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  const tabs: { id: Tab; label: string; icon: typeof Settings }[] = [
    { id: 'overview', label: 'Overview', icon: Settings },
    { id: 'logo', label: 'Logo', icon: Palette },
    { id: 'hero', label: 'Hero Section', icon: Type },
    { id: 'services', label: 'Services', icon: DollarSign },
    { id: 'offers', label: 'Offers', icon: Gift },
    { id: 'portfolio', label: 'Portfolio', icon: Image },
    { id: 'reviews', label: 'Reviews', icon: Star },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
    { id: 'trust', label: 'Trust Stats', icon: Check },
    { id: 'social', label: 'Social Links', icon: Link2 },
    { id: 'texts', label: 'Site Texts', icon: FileText },
    { id: 'tools', label: 'Tools', icon: Wrench },
    { id: 'coupons', label: 'Coupons', icon: Ticket },
    { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle },
  ];

  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-surface flex pt-16">
      {/* Save notification */}
      {saved && (
        <div className="fixed top-20 right-4 z-50 bg-green-500 text-white px-4 py-2 rounded-xl shadow-lg flex items-center gap-2 animate-slide-up">
          <Check size={16} /> Changes saved!
        </div>
      )}

      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} bg-white border-r border-gray-100 flex flex-col transition-all duration-300 shrink-0 fixed top-16 bottom-0 z-40`}>
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          {sidebarOpen && <h2 className="font-bold text-sm">Admin Panel</h2>}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1 hover:bg-gray-100 rounded-lg">
            {sidebarOpen ? <ChevronDown size={16} className="rotate-90" /> : <ChevronRight size={16} />}
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto p-2 space-y-1">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === t.id ? 'bg-primary text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <t.icon size={18} className="shrink-0" />
              {sidebarOpen && t.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-gray-100">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 transition-all"
          >
            <LogOut size={18} className="shrink-0" />
            {sidebarOpen && 'Logout'}
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className={`flex-1 ${sidebarOpen ? 'ml-64' : 'ml-16'} transition-all duration-300`}>
        <div className="p-6 max-w-5xl mx-auto">
          <motion.div key={tab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>

            {/* OVERVIEW */}
            {tab === 'overview' && (
              <div>
                {/* BACKEND PERSISTENCE BANNER */}
                <div className={`mb-6 p-5 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                  isLive 
                    ? 'bg-green-50 border-green-200 text-green-800' 
                    : 'bg-amber-50 border-amber-200 text-amber-800'
                }`}>
                  <div className="flex items-start gap-3">
                    <span className={`h-3 w-3 rounded-full mt-1.5 animate-pulse ${isLive ? 'bg-green-500' : 'bg-amber-500'}`} />
                    <div>
                      <h4 className="font-bold text-sm">
                        {isLive ? 'PostgreSQL Live Database Connected' : 'Website Running in Local Mode'}
                      </h4>
                      <p className="text-xs opacity-80 mt-0.5 max-w-xl">
                        {isLive 
                          ? 'All changes made in this dashboard are permanently saved in your PostgreSQL backend database. Updates reflect globally for all users instantly.' 
                          : 'You are currently saving data to your browser only. To save globally for all users, start your Python Django server with PostgreSQL.'}
                      </p>
                    </div>
                  </div>
                  {!isLive && (
                    <button 
                      onClick={() => alert("Check the backend/README.md file in the project directory for full step-by-step instructions on running your live Python Django & PostgreSQL backend.")}
                      className="text-xs bg-amber-600 hover:bg-amber-700 text-white font-medium px-4 py-2 rounded-xl shrink-0 shadow-sm"
                    >
                      How to Go Live
                    </button>
                  )}
                </div>

                <h1 className="text-3xl font-bold font-[Space_Grotesk] mb-8">Dashboard Overview</h1>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  {[
                    { label: 'Total Orders', value: data.orders.length, emoji: '📦' },
                    { label: 'Services', value: data.services.length, emoji: '🎬' },
                    { label: 'Reviews', value: data.reviews.length, emoji: '⭐' },
                    { label: 'Coupons', value: data.coupons.filter(c => c.active).length, emoji: '🎫' },
                  ].map(s => (
                    <div key={s.label} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <span className="text-2xl">{s.emoji}</span>
                      <div className="text-2xl font-bold font-[Space_Grotesk] mt-2">{s.value}</div>
                      <p className="text-sm text-muted">{s.label}</p>
                    </div>
                  ))}
                </div>

                <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-8">
                  <h3 className="font-bold mb-2">Currency Settings</h3>
                  <p className="text-sm text-muted mb-4">Select the default currency symbol displayed across the entire website.</p>
                  <div className="flex gap-4">
                    <button
                      onClick={() => {
                        updateField('currency', 'USD');
                        updateField('currencySymbol', '$');
                        showSaved();
                      }}
                      className={`px-6 py-3 rounded-xl font-semibold border transition-all ${
                        data.currency === 'USD' ? 'bg-primary text-white border-primary' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      $ US Dollars (USD)
                    </button>
                    <button
                      onClick={() => {
                        updateField('currency', 'PKR');
                        updateField('currencySymbol', '₨');
                        showSaved();
                      }}
                      className={`px-6 py-3 rounded-xl font-semibold border transition-all ${
                        data.currency === 'PKR' ? 'bg-primary text-white border-primary' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      ₨ Pakistani Rupees (PKR)
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 border border-gray-100">
                  <h3 className="font-bold mb-4">Recent Orders</h3>
                  {data.orders.length === 0 ? (
                    <p className="text-muted text-sm">No orders yet</p>
                  ) : (
                    <div className="space-y-3">
                      {data.orders.slice(-5).reverse().map(o => (
                        <div key={o.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                          <div>
                            <span className="font-mono text-sm font-bold text-accent">{o.id}</span>
                            <p className="text-sm text-muted">{o.name} - {o.serviceType}</p>
                          </div>
                          <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                            o.status === 'delivered' ? 'bg-green-100 text-green-700' :
                            o.status === 'editing' ? 'bg-blue-100 text-blue-700' :
                            o.status === 'rendering' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-gray-100 text-gray-700'
                          }`}>
                            {o.status.toUpperCase()}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* LOGO */}
            {tab === 'logo' && (
              <div>
                <h1 className="text-3xl font-bold font-[Space_Grotesk] mb-8">Logo Settings</h1>
                <div className="bg-white rounded-2xl p-6 border border-gray-100 space-y-6">
                  <div>
                    <label className="block text-sm font-semibold mb-1">Logo Text</label>
                    <input
                      type="text"
                      value={data.logo.text}
                      onChange={e => updateField('logo', { ...data.logo, text: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Logo Color</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={data.logo.color}
                        onChange={e => updateField('logo', { ...data.logo, color: e.target.value })}
                        className="w-12 h-12 rounded-xl cursor-pointer border-0"
                      />
                      <input
                        type="text"
                        value={data.logo.color}
                        onChange={e => updateField('logo', { ...data.logo, color: e.target.value })}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent w-40"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Logo Image URL (optional, overrides text)</label>
                    <input
                      type="text"
                      value={data.logo.imageUrl}
                      onChange={e => updateField('logo', { ...data.logo, imageUrl: e.target.value })}
                      placeholder="https://example.com/logo.png"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent mb-2"
                    />
                    <label className="block text-xs font-medium text-muted mb-1 font-bold text-accent">Ya phir apne computer se file select karein:</label>
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            updateField('logo', { ...data.logo, imageUrl: reader.result as string });
                          };
                          reader.readAsDataURL(file);
                        }
                      }} 
                      className="text-xs text-muted block w-full file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-accent/10 file:text-accent hover:file:bg-accent/20 cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Animation Type</label>
                    <select
                      value={data.logo.animationType}
                      onChange={e => updateField('logo', { ...data.logo, animationType: e.target.value as 'fade' | 'slide' | 'scale' | 'typewriter' })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent bg-white"
                    >
                      <option value="typewriter">Typewriter</option>
                      <option value="fade">Fade In</option>
                      <option value="slide">Slide Up</option>
                      <option value="scale">Scale In</option>
                    </select>
                  </div>
                  <div className="pt-4 border-t">
                    <p className="text-sm font-semibold mb-2">Preview:</p>
                    <div className="p-8 bg-gray-50 rounded-xl text-center">
                      {data.logo.imageUrl ? (
                        <img src={data.logo.imageUrl} alt="Logo" className="h-12 mx-auto" />
                      ) : (
                        <span className="text-3xl font-bold font-[Space_Grotesk]" style={{ color: data.logo.color }}>
                          {data.logo.text}
                        </span>
                      )}
                    </div>
                  </div>
                  <button onClick={showSaved} className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2">
                    <Save size={18} /> Save Changes
                  </button>
                </div>
              </div>
            )}

            {/* HERO */}
            {tab === 'hero' && (
              <div>
                <h1 className="text-3xl font-bold font-[Space_Grotesk] mb-8">Hero Section</h1>
                <div className="bg-white rounded-2xl p-6 border border-gray-100 space-y-6">
                  <div>
                    <label className="block text-sm font-semibold mb-1">Hero Title</label>
                    <input
                      type="text"
                      value={data.hero.title}
                      onChange={e => updateField('hero', { ...data.hero, title: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Hero Subtitle</label>
                    <input
                      type="text"
                      value={data.hero.subtitle}
                      onChange={e => updateField('hero', { ...data.hero, subtitle: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">CTA Button Text</label>
                    <input
                      type="text"
                      value={data.hero.ctaText}
                      onChange={e => updateField('hero', { ...data.hero, ctaText: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent"
                    />
                  </div>
                  <button onClick={showSaved} className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2">
                    <Save size={18} /> Save Changes
                  </button>
                </div>
              </div>
            )}

            {/* SERVICES */}
            {tab === 'services' && (
              <div>
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold font-[Space_Grotesk]">Services</h1>
                  <button
                    onClick={() => {
                      updateField('services', [...data.services, {
                        id: Date.now().toString(),
                        name: 'New Service',
                        description: 'Service description',
                        price: 0,
                        deliveryTime: '1-2 Days',
                        features: ['Feature 1'],
                        popular: false,
                      }]);
                    }}
                    className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-light transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Add Service
                  </button>
                </div>
                <div className="space-y-4">
                  {data.services.map((service, i) => (
                    <div key={service.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="font-bold">{service.name}</h3>
                        <button
                          onClick={() => updateField('services', data.services.filter(s => s.id !== service.id))}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Name</label>
                          <input
                            type="text"
                            value={service.name}
                            onChange={e => {
                              const s = [...data.services];
                              s[i] = { ...s[i], name: e.target.value };
                              updateField('services', s);
                            }}
                            className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Price ($)</label>
                          <input
                            type="number"
                            value={service.price}
                            onChange={e => {
                              const s = [...data.services];
                              s[i] = { ...s[i], price: +e.target.value };
                              updateField('services', s);
                            }}
                            className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Delivery Time</label>
                          <input
                            type="text"
                            value={service.deliveryTime}
                            onChange={e => {
                              const s = [...data.services];
                              s[i] = { ...s[i], deliveryTime: e.target.value };
                              updateField('services', s);
                            }}
                            className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm"
                          />
                        </div>
                        <div>
                          <label className="flex items-center gap-2 text-xs font-semibold text-muted cursor-pointer mt-4">
                            <input
                              type="checkbox"
                              checked={service.popular || false}
                              onChange={e => {
                                const s = [...data.services];
                                s[i] = { ...s[i], popular: e.target.checked };
                                updateField('services', s);
                              }}
                              className="accent-accent"
                            />
                            Mark as Popular
                          </label>
                        </div>
                      </div>
                      <div className="mt-3">
                        <label className="block text-xs font-semibold mb-1 text-muted">Description</label>
                        <textarea
                          value={service.description}
                          onChange={e => {
                            const s = [...data.services];
                            s[i] = { ...s[i], description: e.target.value };
                            updateField('services', s);
                          }}
                          rows={2}
                          className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm resize-none"
                        />
                      </div>
                      <div className="mt-3">
                        <label className="block text-xs font-semibold mb-1 text-muted">Features (one per line)</label>
                        <textarea
                          value={service.features.join('\n')}
                          onChange={e => {
                            const s = [...data.services];
                            s[i] = { ...s[i], features: e.target.value.split('\n') };
                            updateField('services', s);
                          }}
                          rows={3}
                          className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm resize-none"
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2">
                  <Save size={18} /> Save All
                </button>
              </div>
            )}

            {/* OFFERS */}
            {tab === 'offers' && (
              <div>
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold font-[Space_Grotesk]">Offers</h1>
                  <button
                    onClick={() => {
                      updateField('offers', [...data.offers, {
                        id: Date.now().toString(),
                        title: 'New Offer',
                        description: 'Offer description',
                        originalPrice: 50,
                        discountPrice: 35,
                        badge: 'NEW',
                        features: ['Feature 1'],
                      }]);
                    }}
                    className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-light transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Add Offer
                  </button>
                </div>
                <div className="space-y-4">
                  {data.offers.map((offer, i) => (
                    <div key={offer.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="font-bold">{offer.title}</h3>
                        <button onClick={() => updateField('offers', data.offers.filter(o => o.id !== offer.id))} className="p-2 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 size={16} /></button>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Title</label>
                          <input value={offer.title} onChange={e => { const o = [...data.offers]; o[i] = { ...o[i], title: e.target.value }; updateField('offers', o); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Badge</label>
                          <input value={offer.badge} onChange={e => { const o = [...data.offers]; o[i] = { ...o[i], badge: e.target.value }; updateField('offers', o); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Original Price ($)</label>
                          <input type="number" value={offer.originalPrice} onChange={e => { const o = [...data.offers]; o[i] = { ...o[i], originalPrice: +e.target.value }; updateField('offers', o); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Discount Price ($)</label>
                          <input type="number" value={offer.discountPrice} onChange={e => { const o = [...data.offers]; o[i] = { ...o[i], discountPrice: +e.target.value }; updateField('offers', o); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                      </div>
                      <div className="mt-3">
                        <label className="block text-xs font-semibold mb-1 text-muted">Description</label>
                        <textarea value={offer.description} onChange={e => { const o = [...data.offers]; o[i] = { ...o[i], description: e.target.value }; updateField('offers', o); }} rows={2} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm resize-none" />
                      </div>
                      <div className="mt-3">
                        <label className="block text-xs font-semibold mb-1 text-muted">Features (one per line)</label>
                        <textarea value={offer.features.join('\n')} onChange={e => { const o = [...data.offers]; o[i] = { ...o[i], features: e.target.value.split('\n') }; updateField('offers', o); }} rows={3} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm resize-none" />
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

            {/* PORTFOLIO */}
            {tab === 'portfolio' && (
              <div>
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold font-[Space_Grotesk]">Portfolio</h1>
                  <button
                    onClick={() => {
                      updateField('portfolio', [...data.portfolio, {
                        id: Date.now().toString(),
                        title: 'New Work',
                        category: 'Reel Edits',
                        imageUrl: '',
                        description: 'Project description',
                      }]);
                    }}
                    className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-light transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Add Item
                  </button>
                </div>
                <div className="space-y-4">
                  {data.portfolio.map((item, i) => (
                    <div key={item.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="font-bold">{item.title}</h3>
                        <button onClick={() => updateField('portfolio', data.portfolio.filter(p => p.id !== item.id))} className="p-2 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 size={16} /></button>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Title</label>
                          <input value={item.title} onChange={e => { const p = [...data.portfolio]; p[i] = { ...p[i], title: e.target.value }; updateField('portfolio', p); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Category</label>
                          <select value={item.category} onChange={e => { const p = [...data.portfolio]; p[i] = { ...p[i], category: e.target.value }; updateField('portfolio', p); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm bg-white">
                            {['Reel Edits', 'YouTube Edits', 'Cinematic Edits', 'Color Grading', 'Before/After'].map(c => <option key={c}>{c}</option>)}
                          </select>
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-xs font-semibold mb-1 text-muted font-bold text-accent">Image URL (Ya phir niche se file select karein)</label>
                          <input value={item.imageUrl} onChange={e => { const p = [...data.portfolio]; p[i] = { ...p[i], imageUrl: e.target.value }; updateField('portfolio', p); }} placeholder="https://..." className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                          <div className="mt-2">
                            <input 
                              type="file" 
                              accept="image/*" 
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    const p = [...data.portfolio];
                                    p[i] = { ...p[i], imageUrl: reader.result as string };
                                    updateField('portfolio', p);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }} 
                              className="text-xs text-muted block w-full file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-accent/10 file:text-accent hover:file:bg-accent/20 cursor-pointer"
                            />
                          </div>
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-xs font-semibold mb-1 text-muted">Description</label>
                          <input value={item.description} onChange={e => { const p = [...data.portfolio]; p[i] = { ...p[i], description: e.target.value }; updateField('portfolio', p); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

            {/* REVIEWS */}
            {tab === 'reviews' && (
              <div>
                <h1 className="text-3xl font-bold font-[Space_Grotesk] mb-8">Reviews Management</h1>
                <div className="space-y-4">
                  {data.reviews.map((review, i) => (
                    <div key={review.id} className={`bg-white rounded-2xl p-6 border ${review.highlighted ? 'border-accent' : 'border-gray-100'}`}>
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold">{review.name}</span>
                            <div className="flex gap-0.5">
                              {[1,2,3,4,5].map(s => (
                                <Star key={s} size={12} className={s <= review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'} />
                              ))}
                            </div>
                          </div>
                          <p className="text-xs text-muted mt-1">{review.date}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              const r = [...data.reviews];
                              r[i] = { ...r[i], approved: !r[i].approved };
                              updateField('reviews', r);
                            }}
                            className={`p-2 rounded-lg transition-all ${review.approved ? 'text-green-500 bg-green-50' : 'text-gray-400 bg-gray-50'}`}
                            title={review.approved ? 'Approved' : 'Pending'}
                          >
                            {review.approved ? <Eye size={16} /> : <X size={16} />}
                          </button>
                          <button
                            onClick={() => {
                              const r = [...data.reviews];
                              r[i] = { ...r[i], highlighted: !r[i].highlighted };
                              updateField('reviews', r);
                            }}
                            className={`p-2 rounded-lg transition-all ${review.highlighted ? 'text-accent bg-accent/10' : 'text-gray-400 bg-gray-50'}`}
                            title="Highlight"
                          >
                            <Star size={16} />
                          </button>
                          <button
                            onClick={() => updateField('reviews', data.reviews.filter(r => r.id !== review.id))}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                      <p className="text-sm text-gray-700">"{review.comment}"</p>
                      <div className="flex gap-2 mt-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${review.approved ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                          {review.approved ? 'Approved' : 'Pending'}
                        </span>
                        {review.highlighted && <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-accent/10 text-accent">Featured</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ORDERS */}
            {tab === 'orders' && (
              <div>
                <h1 className="text-3xl font-bold font-[Space_Grotesk] mb-8">Orders</h1>
                {data.orders.length === 0 ? (
                  <div className="bg-white rounded-2xl p-12 border border-gray-100 text-center">
                    <span className="text-4xl">📦</span>
                    <p className="text-muted mt-4">No orders yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {data.orders.slice().reverse().map((order, idx) => {
                      const i = data.orders.length - 1 - idx;
                      return (
                        <div key={order.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 mb-4">
                            <div>
                              <span className="font-mono text-sm font-bold text-accent">{order.id}</span>
                              <h3 className="font-bold">{order.name}</h3>
                              <p className="text-sm text-muted">{order.email} • {order.date}</p>
                            </div>
                            <select
                              value={order.status}
                              onChange={e => {
                                const o = [...data.orders];
                                o[i] = { ...o[i], status: e.target.value as 'received' | 'editing' | 'rendering' | 'delivered' };
                                updateField('orders', o);
                              }}
                              className={`px-3 py-1.5 rounded-lg text-sm font-bold border-0 ${
                                order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                                order.status === 'editing' ? 'bg-blue-100 text-blue-700' :
                                order.status === 'rendering' ? 'bg-yellow-100 text-yellow-700' :
                                'bg-gray-100 text-gray-700'
                              }`}
                            >
                              <option value="received">Received</option>
                              <option value="editing">Editing</option>
                              <option value="rendering">Rendering</option>
                              <option value="delivered">Delivered</option>
                            </select>
                          </div>
                          <div className="grid sm:grid-cols-2 gap-3 text-sm">
                            <div><span className="text-muted">Service:</span> {order.serviceType}</div>
                            <div><span className="text-muted">Video Length:</span> {order.videoLength || 'N/A'}</div>
                            {order.fileName && <div><span className="text-muted">File:</span> {order.fileName}</div>}
                          </div>
                          {order.description && <p className="text-sm mt-3 p-3 bg-gray-50 rounded-lg">{order.description}</p>}
                          <div className="mt-3">
                            <button onClick={() => updateField('orders', data.orders.filter(o => o.id !== order.id))} className="text-xs text-red-500 hover:underline">Delete Order</button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TRUST STATS */}
            {tab === 'trust' && (
              <div>
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold font-[Space_Grotesk]">Trust Statistics</h1>
                  <button
                    onClick={() => updateField('trustStats', [...data.trustStats, { id: Date.now().toString(), label: 'New Stat', value: '0', icon: 'star' }])}
                    className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-light transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Add Stat
                  </button>
                </div>
                <div className="space-y-4">
                  {data.trustStats.map((stat, i) => (
                    <div key={stat.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <div className="grid sm:grid-cols-3 gap-4 items-end">
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Value</label>
                          <input value={stat.value} onChange={e => { const t = [...data.trustStats]; t[i] = { ...t[i], value: e.target.value }; updateField('trustStats', t); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Label</label>
                          <input value={stat.label} onChange={e => { const t = [...data.trustStats]; t[i] = { ...t[i], label: e.target.value }; updateField('trustStats', t); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <button onClick={() => updateField('trustStats', data.trustStats.filter(t => t.id !== stat.id))} className="p-2 text-red-500 hover:bg-red-50 rounded-lg w-fit"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

            {/* SOCIAL LINKS */}
            {tab === 'social' && (
              <div>
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold font-[Space_Grotesk]">Social Links</h1>
                  <button
                    onClick={() => updateField('socialLinks', [...data.socialLinks, { id: Date.now().toString(), platform: 'New Platform', url: 'https://', icon: 'link' }])}
                    className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-light transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Add Link
                  </button>
                </div>
                <div className="space-y-4">
                  {data.socialLinks.map((link, i) => (
                    <div key={link.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <div className="grid sm:grid-cols-3 gap-4 items-end">
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Platform</label>
                          <input value={link.platform} onChange={e => { const s = [...data.socialLinks]; s[i] = { ...s[i], platform: e.target.value }; updateField('socialLinks', s); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">URL</label>
                          <input value={link.url} onChange={e => { const s = [...data.socialLinks]; s[i] = { ...s[i], url: e.target.value }; updateField('socialLinks', s); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <button onClick={() => updateField('socialLinks', data.socialLinks.filter(s => s.id !== link.id))} className="p-2 text-red-500 hover:bg-red-50 rounded-lg w-fit"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

            {/* SITE TEXTS */}
            {tab === 'texts' && (
              <div>
                <h1 className="text-3xl font-bold font-[Space_Grotesk] mb-8">Site Texts</h1>
                <div className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4">
                  {Object.entries(data.siteTexts).map(([key, val]) => (
                    <div key={key}>
                      <label className="block text-xs font-semibold mb-1 text-muted capitalize">{key.replace(/([A-Z])/g, ' $1')}</label>
                      <input
                        value={val}
                        onChange={e => updateField('siteTexts', { ...data.siteTexts, [key]: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm"
                      />
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

            {/* TOOLS */}
            {tab === 'tools' && (
              <div>
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold font-[Space_Grotesk]">Tools</h1>
                  <button
                    onClick={() => updateField('tools', [...data.tools, { id: Date.now().toString(), name: 'New Tool', description: 'Tool description', icon: 'wrench', available: false }])}
                    className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-light transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Add Tool
                  </button>
                </div>
                <div className="space-y-4">
                  {data.tools.map((tool, i) => (
                    <div key={tool.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <div className="grid sm:grid-cols-2 gap-4 items-end">
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Name</label>
                          <input value={tool.name} onChange={e => { const t = [...data.tools]; t[i] = { ...t[i], name: e.target.value }; updateField('tools', t); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Description</label>
                          <input value={tool.description} onChange={e => { const t = [...data.tools]; t[i] = { ...t[i], description: e.target.value }; updateField('tools', t); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <label className="flex items-center gap-2 text-sm cursor-pointer">
                          <input
                            type="checkbox"
                            checked={tool.available}
                            onChange={e => { const t = [...data.tools]; t[i] = { ...t[i], available: e.target.checked }; updateField('tools', t); }}
                            className="accent-accent"
                          />
                          Available
                        </label>
                        <button onClick={() => updateField('tools', data.tools.filter(t => t.id !== tool.id))} className="p-2 text-red-500 hover:bg-red-50 rounded-lg w-fit"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

            {/* COUPONS */}
            {tab === 'coupons' && (
              <div>
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold font-[Space_Grotesk]">Coupons</h1>
                  <button
                    onClick={() => updateField('coupons', [...data.coupons, { id: Date.now().toString(), code: 'NEW' + Math.floor(Math.random()*100), discount: 10, type: 'percent' as const, active: true }])}
                    className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-light transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Add Coupon
                  </button>
                </div>
                <div className="space-y-4">
                  {data.coupons.map((coupon, i) => (
                    <div key={coupon.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                      <div className="grid sm:grid-cols-4 gap-4 items-end">
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Code</label>
                          <input value={coupon.code} onChange={e => { const c = [...data.coupons]; c[i] = { ...c[i], code: e.target.value.toUpperCase() }; updateField('coupons', c); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm font-mono" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Discount</label>
                          <input type="number" value={coupon.discount} onChange={e => { const c = [...data.coupons]; c[i] = { ...c[i], discount: +e.target.value }; updateField('coupons', c); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold mb-1 text-muted">Type</label>
                          <select value={coupon.type} onChange={e => { const c = [...data.coupons]; c[i] = { ...c[i], type: e.target.value as 'percent' | 'fixed' }; updateField('coupons', c); }} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-accent text-sm bg-white">
                            <option value="percent">Percent (%)</option>
                            <option value="fixed">Fixed ($)</option>
                          </select>
                        </div>
                        <div className="flex gap-2 items-center">
                          <label className="flex items-center gap-2 text-sm cursor-pointer">
                            <input type="checkbox" checked={coupon.active} onChange={e => { const c = [...data.coupons]; c[i] = { ...c[i], active: e.target.checked }; updateField('coupons', c); }} className="accent-accent" />
                            Active
                          </label>
                          <button onClick={() => updateField('coupons', data.coupons.filter(c => c.id !== coupon.id))} className="p-2 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

            {/* WHATSAPP */}
            {tab === 'whatsapp' && (
              <div>
                <h1 className="text-3xl font-bold font-[Space_Grotesk] mb-8">WhatsApp Settings</h1>
                <div className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4">
                  <div>
                    <label className="block text-sm font-semibold mb-1">Phone Number</label>
                    <input value={data.whatsapp.phone} onChange={e => updateField('whatsapp', { ...data.whatsapp, phone: e.target.value })} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Default Message</label>
                    <textarea value={data.whatsapp.message} onChange={e => updateField('whatsapp', { ...data.whatsapp, message: e.target.value })} rows={3} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-accent resize-none" />
                  </div>
                </div>
                <button onClick={showSaved} className="mt-4 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-gray-800 transition-all flex items-center gap-2"><Save size={18} /> Save All</button>
              </div>
            )}

          </motion.div>
        </div>
      </main>
    </div>
  );
}
