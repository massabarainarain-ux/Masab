import { MessageCircle } from 'lucide-react';
import { useSite } from '../context/SiteContext';

export default function WhatsAppButton() {
  const { data } = useSite();
  const url = `https://wa.me/${data.whatsapp.phone.replace(/\D/g, '')}?text=${encodeURIComponent(data.whatsapp.message)}`;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-500 rounded-full flex items-center justify-center shadow-lg hover:bg-green-600 hover:scale-110 transition-all duration-300 group"
    >
      <MessageCircle size={28} className="text-white fill-white" />
      <span className="absolute right-full mr-3 bg-white text-gray-800 text-sm font-medium px-3 py-2 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
        Chat on WhatsApp
      </span>
    </a>
  );
}
