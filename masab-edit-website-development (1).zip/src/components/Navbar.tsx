import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useSite } from '../context/SiteContext';
import { Menu, X, Shield } from 'lucide-react';

export default function Navbar() {
  const { data, isAdmin } = useSite();
  const [open, setOpen] = useState(false);
  const location = useLocation();

  const links = [
    { to: '/', label: 'Home' },
    { to: '/services', label: 'Services' },
    { to: '/portfolio', label: 'Portfolio' },
    { to: '/offers', label: 'Offers' },
    { to: '/reviews', label: 'Reviews' },
    { to: '/tools', label: 'Tools' },
    { to: '/order', label: 'Order' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            {data.logo.imageUrl ? (
              <img src={data.logo.imageUrl} alt={data.logo.text} className="h-8" />
            ) : (
              <span
                className="text-xl font-bold font-[Space_Grotesk] tracking-tight"
                style={{ color: data.logo.color }}
              >
                {data.logo.text}
              </span>
            )}
          </Link>

          <div className="hidden md:flex items-center gap-1">
            {links.map(l => (
              <Link
                key={l.to}
                to={l.to}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  location.pathname === l.to
                    ? 'bg-primary text-white'
                    : 'text-gray-600 hover:text-primary hover:bg-gray-100'
                }`}
              >
                {l.label}
              </Link>
            ))}
            {isAdmin && (
              <Link
                to="/admin"
                className="ml-2 px-3 py-2 rounded-lg text-sm font-medium bg-accent text-white hover:bg-accent-light transition-all flex items-center gap-1"
              >
                <Shield size={14} /> Admin
              </Link>
            )}
            {!isAdmin && (
              <Link
                to="/admin/login"
                className="ml-2 px-3 py-2 rounded-lg text-sm font-medium text-gray-400 hover:text-gray-600 transition-all"
              >
                <Shield size={14} />
              </Link>
            )}
          </div>

          <button className="md:hidden p-2" onClick={() => setOpen(!open)}>
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-gray-100 bg-white">
          <div className="px-4 py-2 space-y-1">
            {links.map(l => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className={`block px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  location.pathname === l.to
                    ? 'bg-primary text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {l.label}
              </Link>
            ))}
            <Link
              to={isAdmin ? '/admin' : '/admin/login'}
              onClick={() => setOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-accent hover:bg-gray-100"
            >
              {isAdmin ? '⚙️ Admin Dashboard' : '🔒 Admin'}
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
