import { Link } from 'react-router-dom';
import { useSite } from '../context/SiteContext';
import { Heart, ExternalLink } from 'lucide-react';

export default function Footer() {
  const { data } = useSite();

  const platformEmoji: Record<string, string> = {
    instagram: '📸',
    youtube: '🎬',
    tiktok: '🎵',
    discord: '🎮',
  };

  return (
    <footer className="bg-primary text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-bold font-[Space_Grotesk] mb-4">{data.logo.text}</h3>
            <p className="text-gray-400 max-w-md mb-6">{data.hero.subtitle}</p>
            <div className="flex gap-3">
              {data.socialLinks.map(link => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-accent transition-all duration-300 hover:scale-110 text-lg"
                  title={link.platform}
                >
                  {platformEmoji[link.icon] || <ExternalLink size={18} />}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-gray-300 uppercase text-xs tracking-wider">Quick Links</h4>
            <div className="space-y-2">
              {[
                { path: '/', label: 'Home' },
                { path: '/services', label: 'Services' },
                { path: '/portfolio', label: 'Portfolio' },
                { path: '/offers', label: 'Offers' },
                { path: '/reviews', label: 'Reviews' },
                { path: '/order', label: 'Order' },
              ].map(l => (
                <Link
                  key={l.path}
                  to={l.path}
                  className="block text-gray-400 hover:text-white transition-colors text-sm"
                >
                  {l.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-gray-300 uppercase text-xs tracking-wider">Contact</h4>
            <div className="space-y-2 text-sm text-gray-400">
              <p>WhatsApp: {data.whatsapp.phone}</p>
              <p>Email: massabarainarain@gmail.com</p>
              <Link to="/order" className="inline-block mt-4 px-4 py-2 bg-accent rounded-lg text-white text-sm hover:bg-accent-light transition-all">
                Order Now
              </Link>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">{data.siteTexts.footerText}</p>
          <p className="text-gray-500 text-sm flex items-center gap-1">
            Made with <Heart size={14} className="text-red-500 fill-red-500" /> by Masab
          </p>
        </div>
      </div>
    </footer>
  );
}
