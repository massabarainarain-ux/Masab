import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSite } from '../context/SiteContext';

export default function IntroAnimation({ onComplete }: { onComplete: () => void }) {
  const { data } = useSite();
  const [phase, setPhase] = useState(0); // 0=animate, 1=hold, 2=exit

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 1200);
    const t2 = setTimeout(() => setPhase(2), 2200);
    const t3 = setTimeout(onComplete, 2800);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onComplete]);

  const anim = data.logo.animationType;

  const variants = {
    typewriter: {
      initial: { width: 0, opacity: 0 } as const,
      animate: { width: 'auto' as const, opacity: 1, transition: { duration: 1, ease: 'easeOut' as const } },
    },
    fade: {
      initial: { opacity: 0 },
      animate: { opacity: 1, transition: { duration: 1 } },
    },
    slide: {
      initial: { opacity: 0, y: 60 },
      animate: { opacity: 1, y: 0, transition: { duration: 0.8, ease: 'easeOut' as const } },
    },
    scale: {
      initial: { opacity: 0, scale: 0.5 },
      animate: { opacity: 1, scale: 1, transition: { duration: 0.8, ease: [0.34, 1.56, 0.64, 1] as const } },
    },
  };

  const v = variants[anim] || variants.typewriter;

  return (
    <AnimatePresence>
      {phase < 2 && (
        <motion.div
          className="fixed inset-0 z-[100] bg-white flex items-center justify-center"
          exit={{ opacity: 0, transition: { duration: 0.5 } }}
        >
          <motion.div
            initial={v.initial}
            animate={v.animate}
            className="overflow-hidden"
          >
            {data.logo.imageUrl ? (
              <img src={data.logo.imageUrl} alt={data.logo.text} className="h-16" />
            ) : (
              <h1
                className="text-5xl sm:text-7xl font-bold font-[Space_Grotesk] whitespace-nowrap tracking-tight"
                style={{ color: data.logo.color }}
              >
                {data.logo.text}
              </h1>
            )}
          </motion.div>

          {/* Decorative line */}
          <motion.div
            className="absolute bottom-1/2 mt-20 h-0.5 bg-accent/20"
            initial={{ width: 0 }}
            animate={{ width: '200px', transition: { duration: 1.5, delay: 0.5 } }}
            style={{ top: '58%' }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
