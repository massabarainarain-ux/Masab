export interface SiteData {
  logo: {
    text: string;
    color: string;
    imageUrl: string;
    animationType: 'fade' | 'slide' | 'scale' | 'typewriter';
  };
  hero: {
    title: string;
    subtitle: string;
    ctaText: string;
  };
  services: ServiceItem[];
  portfolio: PortfolioItem[];
  offers: OfferItem[];
  reviews: ReviewItem[];
  trustStats: TrustStat[];
  socialLinks: SocialLink[];
  tools: ToolItem[];
  coupons: CouponItem[];
  orders: OrderItem[];
  whatsapp: { phone: string; message: string };
  siteTexts: Record<string, string>;
  currency: string;
  currencySymbol: string;
}

export interface ServiceItem {
  id: string;
  name: string;
  description: string;
  price: number;
  deliveryTime: string;
  features: string[];
  popular?: boolean;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  beforeUrl?: string;
  afterUrl?: string;
  description: string;
}

export interface OfferItem {
  id: string;
  title: string;
  description: string;
  originalPrice: number;
  discountPrice: number;
  badge: string;
  features: string[];
}

export interface ReviewItem {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
  approved: boolean;
  highlighted: boolean;
}

export interface TrustStat {
  id: string;
  label: string;
  value: string;
  icon: string;
}

export interface SocialLink {
  id: string;
  platform: string;
  url: string;
  icon: string;
}

export interface ToolItem {
  id: string;
  name: string;
  description: string;
  icon: string;
  available: boolean;
}

export interface CouponItem {
  id: string;
  code: string;
  discount: number;
  type: 'percent' | 'fixed';
  active: boolean;
}

export interface OrderItem {
  id: string;
  name: string;
  email: string;
  serviceType: string;
  videoLength: string;
  description: string;
  status: 'received' | 'editing' | 'rendering' | 'delivered';
  date: string;
  fileName?: string;
}

export const defaultData: SiteData = {
  logo: {
    text: 'MASAB EDIT',
    color: '#111111',
    imageUrl: '',
    animationType: 'typewriter',
  },
  hero: {
    title: 'Professional Video Editing Services',
    subtitle: 'Fast Delivery | High Quality | Creative Edits',
    ctaText: 'Order Now',
  },
  services: [
    {
      id: '1',
      name: 'Normal Edit',
      description: 'Clean cuts, transitions, basic color correction, and text overlays. Perfect for vlogs and simple content.',
      price: 25,
      deliveryTime: '2-3 Days',
      features: ['Basic cuts & transitions', 'Color correction', 'Text overlays', 'Background music', 'Export in HD'],
    },
    {
      id: '2',
      name: 'Custom Edit',
      description: 'Advanced editing with motion graphics, effects, and custom transitions. Great for branded content.',
      price: 50,
      deliveryTime: '3-5 Days',
      features: ['Everything in Normal', 'Motion graphics', 'Custom transitions', 'Sound design', 'Thumbnail design'],
      popular: true,
    },
    {
      id: '3',
      name: 'CC Quality Edit',
      description: 'Cinema-grade color grading, VFX, and premium editing. For content creators who demand the best.',
      price: 100,
      deliveryTime: '5-7 Days',
      features: ['Everything in Custom', 'Cinema color grading', 'Visual effects', '4K export', 'Unlimited revisions'],
    },
  ],
  portfolio: [
    { id: '1', title: 'Cinematic Travel Reel', category: 'Reel Edits', imageUrl: '', description: 'A stunning travel montage with cinematic color grading and smooth transitions.' },
    { id: '2', title: 'YouTube Gaming Edit', category: 'YouTube Edits', imageUrl: '', description: 'Dynamic gaming montage with effects, overlays, and energetic pacing.' },
    { id: '3', title: 'Product Commercial', category: 'Cinematic Edits', imageUrl: '', description: 'High-end product showcase with professional lighting and color grade.' },
    { id: '4', title: 'Color Grading Showcase', category: 'Color Grading', imageUrl: '', description: 'Before and after comparison of professional color grading work.' },
    { id: '5', title: 'Music Video Edit', category: 'Cinematic Edits', imageUrl: '', description: 'Creative music video with beat-synced editing and visual effects.' },
    { id: '6', title: 'Instagram Reels Pack', category: 'Reel Edits', imageUrl: '', description: 'Collection of trending Instagram reels with modern transitions.' },
  ],
  offers: [
    {
      id: '1',
      title: '1 YouTube Video Edit',
      description: 'Complete YouTube video editing up to 10 minutes with all effects included.',
      originalPrice: 50,
      discountPrice: 35,
      badge: 'POPULAR',
      features: ['Up to 10 min video', 'Full editing', 'Thumbnail', 'SEO title suggestions'],
    },
    {
      id: '2',
      title: '10 Reel Edits Bundle',
      description: 'Get 10 professional reel edits at a discounted bundle price.',
      originalPrice: 100,
      discountPrice: 70,
      badge: 'BEST VALUE',
      features: ['10 reel edits', 'Trending effects', 'Music sync', 'Fast delivery'],
    },
    {
      id: '3',
      title: 'My CC Pack',
      description: 'Get my personal color correction preset pack for your own editing projects.',
      originalPrice: 30,
      discountPrice: 20,
      badge: 'EXCLUSIVE',
      features: ['20+ CC presets', 'For Premiere & Resolve', 'Lifetime access', 'Free updates'],
    },
  ],
  reviews: [
    { id: '1', name: 'Alex Turner', rating: 5, comment: 'Absolutely incredible editing! Masab delivered beyond my expectations. The color grading was cinema quality.', date: '2024-12-15', approved: true, highlighted: true },
    { id: '2', name: 'Sarah Chen', rating: 5, comment: 'Fast delivery and amazing quality. My YouTube channel has grown so much since I started working with Masab.', date: '2024-12-20', approved: true, highlighted: false },
    { id: '3', name: 'Mike Johnson', rating: 4, comment: 'Great editing skills and very professional communication. Will definitely order again!', date: '2025-01-05', approved: true, highlighted: false },
    { id: '4', name: 'Emma Wilson', rating: 5, comment: 'The reel edits were trending material! Got thousands of views thanks to the amazing editing.', date: '2025-01-10', approved: true, highlighted: true },
  ],
  trustStats: [
    { id: '1', label: 'Videos Edited', value: '100+', icon: 'video' },
    { id: '2', label: 'Happy Clients', value: '50+', icon: 'users' },
    { id: '3', label: 'Fast Delivery', value: '24h', icon: 'clock' },
    { id: '4', label: 'Pro Editing', value: '5★', icon: 'star' },
  ],
  socialLinks: [
    { id: '1', platform: 'Instagram', url: 'https://instagram.com/masabedit', icon: 'instagram' },
    { id: '2', platform: 'TikTok', url: 'https://tiktok.com/@masabedit', icon: 'tiktok' },
    { id: '3', platform: 'YouTube', url: 'https://youtube.com/@masabedit', icon: 'youtube' },
    { id: '4', platform: 'Discord', url: 'https://discord.gg/masabedit', icon: 'discord' },
  ],
  tools: [
    { id: '1', name: 'Video Editor', description: 'Edit videos online with our powerful editor', icon: 'film', available: true },
    { id: '2', name: 'Add Subtitles', description: 'Auto-generate and add subtitles to videos', icon: 'subtitles', available: true },
    { id: '3', name: 'Compress Video', description: 'Reduce video file size without quality loss', icon: 'compress', available: true },
    { id: '4', name: 'Resize Video', description: 'Change video dimensions for any platform', icon: 'resize', available: true },
    { id: '5', name: 'GIF Maker', description: 'Convert videos to animated GIFs', icon: 'gif', available: true },
    { id: '6', name: 'Merge Video', description: 'Combine multiple videos into one', icon: 'merge', available: true },
    { id: '7', name: 'Video Converter', description: 'Convert videos between formats', icon: 'convert', available: false },
    { id: '8', name: 'Audio Converter', description: 'Convert audio files between formats', icon: 'audio', available: false },
    { id: '9', name: 'Image Converter', description: 'Convert images between formats', icon: 'image', available: false },
    { id: '10', name: 'Text to Speech', description: 'Convert text to natural sounding speech', icon: 'speech', available: false },
  ],
  coupons: [
    { id: '1', code: 'MASAB10', discount: 10, type: 'percent', active: true },
    { id: '2', code: 'WELCOME20', discount: 20, type: 'percent', active: true },
    { id: '3', code: 'SAVE5', discount: 5, type: 'fixed', active: false },
  ],
  orders: [],
  whatsapp: {
    phone: '923172606012',
    message: 'Hi Masab, I want video editing service.',
  },
  siteTexts: {
    servicesTitle: 'Our Services',
    servicesSubtitle: 'Choose the perfect editing package for your content',
    portfolioTitle: 'Our Portfolio',
    portfolioSubtitle: 'Check out our recent editing work',
    offersTitle: 'Special Offers',
    offersSubtitle: 'Limited time deals you don\'t want to miss',
    reviewsTitle: 'Client Reviews',
    reviewsSubtitle: 'What our clients say about us',
    toolsTitle: 'Free Tools',
    toolsSubtitle: 'Powerful editing tools at your fingertips',
    contactTitle: 'Get In Touch',
    contactSubtitle: 'Ready to start your project? Contact us now',
    footerText: '© 2025 Masab Edit. All rights reserved.',
  },
  currency: 'USD',
  currencySymbol: '$',
};
