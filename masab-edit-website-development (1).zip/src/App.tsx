import { useState, useCallback } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { SiteProvider } from './context/SiteContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import IntroAnimation from './components/IntroAnimation';
import Home from './pages/Home';
import Services from './pages/Services';
import Portfolio from './pages/Portfolio';
import Offers from './pages/Offers';
import Reviews from './pages/Reviews';
import Order from './pages/Order';
import Tools from './pages/Tools';
import AdminLogin from './pages/AdminLogin';
import Admin from './pages/Admin';

function ScrollToTop() {
  const location = useLocation();
  useState(() => { window.scrollTo(0, 0); });
  // Trigger scroll on path change
  if (location.pathname) window.scrollTo(0, 0);
  return null;
}

function AppContent() {
  const [showIntro, setShowIntro] = useState(true);
  const handleIntroComplete = useCallback(() => setShowIntro(false), []);
  const location = useLocation();
  const isAdminPage = location.pathname.startsWith('/admin');

  return (
    <>
      {showIntro && !isAdminPage && <IntroAnimation onComplete={handleIntroComplete} />}
      {!isAdminPage && <Navbar />}
      {isAdminPage && <Navbar />}
      <ScrollToTop />
      <main className="min-h-screen">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/offers" element={<Offers />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="/order" element={<Order />} />
          <Route path="/tools" element={<Tools />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </main>
      {!isAdminPage && <Footer />}
      {!isAdminPage && <WhatsAppButton />}
    </>
  );
}

export default function App() {
  return (
    <SiteProvider>
      <Router>
        <AppContent />
      </Router>
    </SiteProvider>
  );
}
