import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SiteData, defaultData, OrderItem, ReviewItem } from '../data/defaultData';
import { apiService } from '../services/apiService';

interface SiteContextType {
  data: SiteData;
  updateData: (newData: Partial<SiteData>) => void;
  updateField: <K extends keyof SiteData>(key: K, value: SiteData[K]) => void;
  isAdmin: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  addOrder: (order: OrderItem) => void;
  addReview: (review: ReviewItem) => void;
  isLive: boolean;
}

const SiteContext = createContext<SiteContextType | undefined>(undefined);

const STORAGE_KEY = 'masab_edit_data';
const AUTH_KEY = 'masab_edit_admin';
const ADMIN_EMAIL = 'massabarainarain@gmail.com';
const ADMIN_PASS = 'massabsocha90807060';

function loadData(): SiteData {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return { ...defaultData, ...parsed };
    }
  } catch (e) {}
  return defaultData;
}

export function SiteProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<SiteData>(loadData);
  const [isAdmin, setIsAdmin] = useState(() => localStorage.getItem(AUTH_KEY) === 'true');

  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    const loadFromDatabase = async () => {
      try {
        const liveData = await apiService.getSiteData();
        if (liveData) {
          setData(liveData);
          setIsLive(true);
        }
      } catch (e) {
        setIsLive(false);
      }
    };
    loadFromDatabase();
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    
    const syncWithDatabase = async () => {
      try {
        await apiService.updateSiteData(data);
        setIsLive(true);
      } catch (e) {
        setIsLive(false);
      }
    };
    syncWithDatabase();

    // Synchronize across multiple browser tabs in real-time
    const channel = new BroadcastChannel('masab_edit_sync');
    channel.postMessage(data);
    channel.close();
  }, [data]);

  useEffect(() => {
    const channel = new BroadcastChannel('masab_edit_sync');
    channel.onmessage = (event) => {
      if (event.data) {
        setData(event.data);
      }
    };
    return () => channel.close();
  }, []);

  const updateData = (newData: Partial<SiteData>) => {
    setData(prev => ({ ...prev, ...newData }));
  };

  const updateField = <K extends keyof SiteData>(key: K, value: SiteData[K]) => {
    setData(prev => ({ ...prev, [key]: value }));
  };

  const login = (email: string, password: string): boolean => {
    if (email === ADMIN_EMAIL && password === ADMIN_PASS) {
      setIsAdmin(true);
      localStorage.setItem(AUTH_KEY, 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAdmin(false);
    localStorage.removeItem(AUTH_KEY);
  };

  const addOrder = (order: OrderItem) => {
    setData(prev => ({ ...prev, orders: [...prev.orders, order] }));
  };

  const addReview = (review: ReviewItem) => {
    setData(prev => ({ ...prev, reviews: [...prev.reviews, review] }));
  };

  return (
    <SiteContext.Provider value={{ data, updateData, updateField, isAdmin, login, logout, addOrder, addReview, isLive }}>
      {children}
    </SiteContext.Provider>
  );
}

export function useSite() {
  const context = useContext(SiteContext);
  if (!context) throw new Error('useSite must be used within SiteProvider');
  return context;
}
