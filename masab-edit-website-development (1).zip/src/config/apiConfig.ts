// Configuration for the backend API connection
// When you host your Django backend on a platform like Render, Heroku, or AWS, 
// replace this URL with your live backend server URL!

export const API_CONFIG = {
  // Example: 'https://api.masabedit.com/api' or 'http://127.0.0.1:8000/api'
  BASE_URL: 'http://127.0.0.1:8000/api',
  USE_LOCAL_FALLBACK: true, // Set to false if you want to strictly use PostgreSQL
};
